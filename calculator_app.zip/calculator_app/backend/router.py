from fastapi import APIRouter
from fastapi.responses import JSONResponse
from schemas import CalculateRequest, CalculateResponse, CalcError
from calculator import calculate, build_expression, CalculationError

router = APIRouter()

@router.post("/calculate", response_model=CalculateResponse)
def calculate_endpoint(request: CalculateRequest) -> CalculateResponse:
    try:
        result = calculate(request.operation, request.operands)
        expression = build_expression(request.operation, request.operands, result)
        return {"result": result, "expression": expression, "operation": request.operation}

    except CalculationError as e:
        return JSONResponse(status_code=422, content={"error_code": e.error_code, "detail": e.detail})
    except Exception:
        return JSONResponse(status_code=500, content={"error_code": "INTERNAL_ERROR", "detail": "An unexpected error occurred"})