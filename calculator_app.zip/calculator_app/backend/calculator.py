from schemas import Operation
import math

BINARY_OPERATORS = {
    Operation.ADD:      "+",
    Operation.SUBTRACT: "-",
    Operation.MULTIPLY: "x",
    Operation.DIVIDE:   "÷",
    Operation.POWER:    "^",
}

class CalculationError(Exception):
    def __init__(self, error_code: str, detail: str):
        self.error_code = error_code
        self.detail     = detail


def calculate(operation: Operation, operands: list[float]) -> float:
    if (operation in BINARY_OPERATORS and len(operands) != 2) or (operation not in BINARY_OPERATORS and len(operands) != 1):
        raise CalculationError(error_code="INVALID_OPERAND_COUNT", detail=f"Invalid number of operands for operation: {operation}")


    if operation == Operation.ADD:
        return operands[0] + operands[1]
    elif operation == Operation.SUBTRACT:
        return operands[0] - operands[1]
    elif operation == Operation.MULTIPLY:
        return operands[0] * operands[1]
    elif operation == Operation.DIVIDE:
        if operands[1] == 0:
            raise CalculationError(error_code="DIVISION_BY_ZERO", detail="Division by zero is not allowed")
        return operands[0] / operands[1]

    elif operation == Operation.POWER:
        try:
            return pow(operands[0], operands[1])
        except OverflowError:
            raise CalculationError(error_code="INVALID_RESULT", detail="Result is too large to represent")
    elif operation == Operation.SQRT:
        if operands[0] < 0:
            raise CalculationError(error_code="SQRT_OF_NEGATIVE", detail="Square root of a negative number")
        return math.sqrt(operands[0])
    elif operation == Operation.PERCENT:
        return operands[0] / 100
    else:
        raise CalculationError(error_code="UNKNOWN_OPERATION", detail=f"Unknown operation: {operation}")


def build_expression(operation: Operation, operands: list[float], result: float) -> str:
    if operation in BINARY_OPERATORS:
        symbol = BINARY_OPERATORS[operation]
        return f"{operands[0]} {symbol} {operands[1]} = {round(result, 10)}"
    if operation == Operation.SQRT:
        return f"√{operands[0]} = {result}"
    if operation == Operation.PERCENT:
        return f"{operands[0]}% = {result}"
    return str(result)
