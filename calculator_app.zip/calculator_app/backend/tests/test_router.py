from unittest.mock import patch
from fastapi.testclient import TestClient
from main import app
from schemas import Operation

client = TestClient(app)

URL = "/api/v1/calculator/calculate"


def post(operation: Operation, operands: list):
    return client.post(URL, json={"operation": operation, "operands": operands})

def assert_success(response, result, operation: Operation):
    assert response.status_code == 200
    body = response.json()
    assert body["result"] == result
    assert body["operation"] == operation
    assert len(body["expression"]) > 0

def assert_domain_error(response, error_code: str):
    assert response.status_code == 422
    body = response.json()
    assert body["error_code"] == error_code
    assert len(body["detail"]) > 0


# --- success: binary operations ---

def test_add():
    assert_success(post(Operation.ADD, [3, 5]), result=8, operation=Operation.ADD)

def test_subtract():
    assert_success(post(Operation.SUBTRACT, [10, 3]), result=7, operation=Operation.SUBTRACT)

def test_multiply():
    assert_success(post(Operation.MULTIPLY, [4, 5]), result=20, operation=Operation.MULTIPLY)

def test_divide():
    assert_success(post(Operation.DIVIDE, [10, 2]), result=5, operation=Operation.DIVIDE)

def test_power():
    assert_success(post(Operation.POWER, [2, 10]), result=1024, operation=Operation.POWER)


# --- success: unary operations ---

def test_sqrt():
    assert_success(post(Operation.SQRT, [9]), result=3, operation=Operation.SQRT)

def test_percent():
    assert_success(post(Operation.PERCENT, [50]), result=0.5, operation=Operation.PERCENT)


# --- success: expression format ---

def test_expression_format_binary():
    body = post(Operation.ADD, [2, 3]).json()
    assert body["expression"] == "2.0 + 3.0 = 5.0"

def test_expression_format_sqrt():
    body = post(Operation.SQRT, [9]).json()
    assert body["expression"] == "√9.0 = 3.0"

def test_expression_format_percent():
    body = post(Operation.PERCENT, [50]).json()
    assert body["expression"] == "50.0% = 0.5"


# --- domain errors ---

def test_division_by_zero():
    assert_domain_error(post(Operation.DIVIDE, [5, 0]), "DIVISION_BY_ZERO")

def test_sqrt_of_negative():
    assert_domain_error(post(Operation.SQRT, [-1]), "SQRT_OF_NEGATIVE")

def test_invalid_operand_count_binary():
    assert_domain_error(post(Operation.ADD, [3]), "INVALID_OPERAND_COUNT")

def test_invalid_operand_count_unary():
    assert_domain_error(post(Operation.SQRT, [3, 9]), "INVALID_OPERAND_COUNT")


# --- malformed requests (Pydantic validation) ---

def test_missing_operation():
    response = client.post(URL, json={"operands": [1, 2]})
    assert response.status_code == 422

def test_missing_operands():
    response = client.post(URL, json={"operation": "add"})
    assert response.status_code == 422

def test_invalid_operation_value():
    response = client.post(URL, json={"operation": "not_valid", "operands": [1, 2]})
    assert response.status_code == 422

def test_empty_body():
    response = client.post(URL, json={})
    assert response.status_code == 422


# --- non-finite results ---

def test_infinite_result():
    response = post(Operation.POWER, [1e308, 2])
    body = response.json()
    assert response.status_code == 422
    assert body["error_code"] == "INVALID_RESULT"
    assert len(body["detail"]) > 0


# --- unexpected internal errors ---

def test_internal_error():
    with patch("router.calculate", side_effect=RuntimeError("unexpected")):
        response = post(Operation.ADD, [1, 2])
    body = response.json()
    assert response.status_code == 500
    assert body["error_code"] == "INTERNAL_ERROR"
    assert len(body["detail"]) > 0