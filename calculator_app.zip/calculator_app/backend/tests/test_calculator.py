import pytest
from calculator import calculate, CalculationError
from schemas import Operation


def test_binary_arithmetic():
    assert calculate(Operation.ADD, [3, 5]) == 8
    assert calculate(Operation.SUBTRACT, [10, 3]) == 7
    assert calculate(Operation.MULTIPLY, [4, 5]) == 20
    assert calculate(Operation.DIVIDE, [10, 2]) == 5
    assert calculate(Operation.POWER, [2, 10]) == 1024

def test_unary_arithmetic():
    assert calculate(Operation.SQRT, [9]) == 3
    assert calculate(Operation.PERCENT, [50]) == 0.5

def test_division_by_zero():
    with pytest.raises(CalculationError) as exc_info:
        calculate(Operation.DIVIDE, [5, 0])
    assert exc_info.value.error_code == "DIVISION_BY_ZERO"

def test_square_root_of_negative():
    with pytest.raises(CalculationError) as exc_info:
        calculate(Operation.SQRT, [-1])
    assert exc_info.value.error_code == "SQRT_OF_NEGATIVE"

def test_invalid_operand_count():
    with pytest.raises(CalculationError) as exc_info:
        calculate(Operation.ADD, [3])
    assert exc_info.value.error_code == "INVALID_OPERAND_COUNT"

    with pytest.raises(CalculationError) as exc_info:
        calculate(Operation.SQRT, [3, 9])
    assert exc_info.value.error_code == "INVALID_OPERAND_COUNT"

def test_unknown_operation():
    with pytest.raises(CalculationError) as exc_info:
        calculate("NOT_AN_OP", [1])
    assert exc_info.value.error_code == "UNKNOWN_OPERATION"

