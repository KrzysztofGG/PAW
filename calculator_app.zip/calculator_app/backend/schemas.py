from enum import Enum
from pydantic import BaseModel


class Operation(str, Enum):
    ADD      = "add"
    SUBTRACT = "subtract"
    MULTIPLY = "multiply"
    DIVIDE   = "divide"
    POWER    = "power"
    SQRT     = "sqrt"
    PERCENT  = "percent"


class CalculateRequest(BaseModel):
    operation: Operation
    operands:  list[float]


class CalculateResponse(BaseModel):
    result:     float
    expression: str
    operation:  Operation


class CalcError(BaseModel):
    error_code: str
    detail:     str
