// String values must exactly match the backend Operation enum.
export enum Operation {
  ADD      = "add",
  SUBTRACT = "subtract",
  MULTIPLY = "multiply",
  DIVIDE   = "divide",
  POWER    = "power",
  SQRT     = "sqrt",
  PERCENT  = "percent",
}

// API response shape — mirrors the backend Pydantic schema.
export interface CalculateResponse {
  result:     number;
  expression: string; // formatted by backend, e.g. "3 + 5 = 8"
  operation:  Operation;
}

// API error shape returned on 4xx responses.
export interface CalcError {
  error_code: string; // e.g. "DIVISION_BY_ZERO"
  detail:     string; // human-readable message shown to the user
}

// Controls the visual style of a CalcButton.
export type ButtonVariant = "number" | "operator" | "action" | "equals";
