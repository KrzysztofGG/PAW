interface DisplayProps {
  display:    string;
  expression: string;
  error:      string | null;
}

export function Display({ display, expression, error }: DisplayProps) {
  const displayValueClass = `display__value ${error === null ? "" : "display__value--error"}`
  return (
    <div className="display">
      <div className="display__expression">{expression}</div>
      <div className={displayValueClass}>{error ?? display}</div>
    </div>
  )
}
