import { useCalculator } from "../hooks/useCalculator";
import { ButtonPad } from "./ButtonPad";
import { Display } from "./Display";

export function Calculator() {
  const {
    display,
    expression,
    error,
    hasPendingOp,
    onDigit,
    onOperator,
    onUnary,
    onEqual,
    onClear,
    onBackspace,
    onToggleSign,
  } = useCalculator();

  return (
    <div className="calculator">
      <Display display={display} expression={expression} error={error} />
      <ButtonPad
        display={display}
        hasPendingOp={hasPendingOp}
        onDigit={onDigit}
        onOperator={onOperator}
        onUnary={onUnary}
        onEqual={onEqual}
        onClear={onClear}
        onBackspace={onBackspace}
        onToggleSign={onToggleSign}
        />
    </div>
  );
}
