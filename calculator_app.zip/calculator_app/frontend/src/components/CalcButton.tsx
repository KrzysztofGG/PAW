import type { ButtonVariant } from "../types";

interface CalcButtonProps {
  label:    string;
  onClick:  () => void;
  variant:  ButtonVariant;
  disabled?: boolean;
  wide?: boolean;
}

export function CalcButton({ label, onClick, variant, disabled = false, wide = false }: CalcButtonProps) {
  const className = `btn btn--${variant}${wide ? " btn--wide" : ""}`;
  return (
    <button className={className} onClick={onClick} disabled={disabled}>
      {label}
    </button>
  );
}
