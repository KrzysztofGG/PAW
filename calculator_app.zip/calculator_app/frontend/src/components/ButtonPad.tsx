import { useEffect } from "react";
import { Operation } from "../types";
import type { ButtonVariant } from "../types";
import { CalcButton } from "./CalcButton";

interface ButtonConfig {
  label:    string;
  variant:  ButtonVariant;
  action:   () => void;
  disabled?: boolean;
  wide?:     boolean;
}

interface ButtonPadProps {
  display:      string;
  hasPendingOp: boolean;
  onDigit:      (digit: string) => void;
  onOperator:   (op: Operation) => void;
  onUnary:      (op: Operation) => void;
  onEqual:      () => void;
  onClear:      () => void;
  onBackspace:  () => void;
  onToggleSign: () => void;
}

const KEY_MAP: Record<string, { type: string; arg?: string | Operation }> = {
  "0": { type: "digit", arg: "0" },
  "1": { type: "digit", arg: "1" },
  "2": { type: "digit", arg: "2" },
  "3": { type: "digit", arg: "3" },
  "4": { type: "digit", arg: "4" },
  "5": { type: "digit", arg: "5" },
  "6": { type: "digit", arg: "6" },
  "7": { type: "digit", arg: "7" },
  "8": { type: "digit", arg: "8" },
  "9": { type: "digit", arg: "9" },
  ".": { type: "digit", arg: "." },
  "+": { type: "operator", arg: Operation.ADD },
  "-": { type: "operator", arg: Operation.SUBTRACT },
  "*": { type: "operator", arg: Operation.MULTIPLY },
  "/": { type: "operator", arg: Operation.DIVIDE },
  "^": { type: "operator", arg: Operation.POWER },
  "r": { type: "unary",    arg: Operation.SQRT },
  "%": { type: "unary",    arg: Operation.PERCENT },
  "Enter": { type: "equal" },
  "=":     { type: "equal" },
  "Escape":    { type: "clear" },
  "Backspace": { type: "backspace" },
};

export function ButtonPad(props: ButtonPadProps) {

  const { display, hasPendingOp, onDigit, onOperator, onUnary, onEqual, onClear, onBackspace, onToggleSign } = props;
  
  const BUTTON_CONFIG: ButtonConfig[] = [
    { label: "√",  variant: "operator", action: () => onUnary(Operation.SQRT) },
    { label: "%",  variant: "operator", action: () => onUnary(Operation.PERCENT) },
    { label: "xʸ", variant: "operator", action: () => onOperator(Operation.POWER) },
    { label: "⌫",  variant: "action",   action: onBackspace },
    { label: "7",  variant: "number",   action: () => onDigit("7") },
    { label: "8",  variant: "number",   action: () => onDigit("8") },
    { label: "9",  variant: "number",   action: () => onDigit("9") },
    { label: "÷",  variant: "operator", action: () => onOperator(Operation.DIVIDE) },
    { label: "4",  variant: "number",   action: () => onDigit("4") },
    { label: "5",  variant: "number",   action: () => onDigit("5") },
    { label: "6",  variant: "number",   action: () => onDigit("6") },
    { label: "x",  variant: "operator", action: () => onOperator(Operation.MULTIPLY) },
    { label: "1",  variant: "number",   action: () => onDigit("1") },
    { label: "2",  variant: "number",   action: () => onDigit("2") },
    { label: "3",  variant: "number",   action: () => onDigit("3") },
    { label: "-",  variant: "operator", action: () => onOperator(Operation.SUBTRACT) },
    { label: ".",  variant: "number",   action: () => onDigit("."), disabled: display.includes(".") },
    { label: "0",  variant: "number",   action: () => onDigit("0") },
    { label: "+/-", variant: "action", action: onToggleSign },
    { label: "+",  variant: "operator", action: () => onOperator(Operation.ADD) },
    { label: "AC", variant: "action",   action: onClear,  wide: true },
    { label: "=",  variant: "equals",   action: onEqual,  wide: true, disabled: !hasPendingOp },
  ];

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      const mapping = KEY_MAP[e.key];
      if (!mapping) return;
      e.preventDefault();

      switch(mapping.type) {
        case "digit":    onDigit(mapping.arg as string); break;
        case "operator": onOperator(mapping.arg as Operation); break;
        case "unary":    onUnary(mapping.arg as Operation); break;
        case "equal":    onEqual(); break;
        case "clear":    onClear(); break;
        case "backspace": onBackspace(); break;
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onDigit, onOperator, onUnary, onEqual, onClear, onBackspace]);
  return (
    <div className="button-pad">
      {BUTTON_CONFIG.map((btn) => (
        <CalcButton key={btn.label} label={btn.label} onClick={btn.action} variant={btn.variant} disabled={btn.disabled} wide={btn.wide} />
      ))}
    </div>
  )
}
