import { useRef, useState } from "react";
import { calculate } from "../services/api";
import { Operation } from "../types";
import type { CalcError } from "../types";

const MAX_DISPLAY_LENGTH = 15;

function formatResult(n: number): string {
  return parseFloat(n.toPrecision(10)).toString();
}

export function useCalculator() {
  const [display, setDisplay]       = useState<string>("0");
  const [expression, setExpression] = useState<string>("");
  const [error, setError]           = useState<string | null>(null);
  const [hasPendingOp, setHasPendingOp] = useState<boolean>(false);

  const leftOperand = useRef<number | null>(null);
  const pendingOp   = useRef<Operation | null>(null);
  const freshResult = useRef<boolean>(false);

  function onDigit(digit: string): void {
    if (error) setError(null);

    if (digit === "." && display.includes(".")) return;

    if (display.length >= MAX_DISPLAY_LENGTH) return;

    if (freshResult.current || (display === "0" && digit !== ".")) {
      freshResult.current = false;
      setDisplay(digit);
      return;
    }

    setDisplay(display + digit);
  }

  async function onOperator(op: Operation): Promise<void> {
    if (pendingOp.current !== null) {
      const result = await onEqual();
      if (result === null) return;
      leftOperand.current = result;
    } else {
      leftOperand.current = parseFloat(display);
    }
    pendingOp.current = op;
    setHasPendingOp(true);
    freshResult.current = true;
  }

  async function onUnary(op: Operation): Promise<void> {
    try {
      const response = await calculate(op, [parseFloat(display)]);
      setDisplay(formatResult(response.result));
      setExpression(response.expression);
      freshResult.current = true;
    } catch (err) {
      onClear();
      setError((err as CalcError).detail ?? "Unknown error");
    }
  }

  async function onEqual(): Promise<number | null> {
    if (leftOperand.current === null || pendingOp.current === null) return null;

    try {
      const response = await calculate(pendingOp.current, [leftOperand.current, parseFloat(display)]);
      setDisplay(formatResult(response.result));
      setExpression(response.expression);
      leftOperand.current = null;
      pendingOp.current = null;
      setHasPendingOp(false);
      freshResult.current = true;
      return response.result;
    } catch (err) {
      onClear();
      setError((err as CalcError).detail ?? "Unknown error");
      return null;
    }
  }

  function onClear(): void {
    setDisplay("0");
    setExpression("");
    setError(null);
    leftOperand.current = null;
    pendingOp.current   = null;
    setHasPendingOp(false);
    freshResult.current = false;
  }

  function onBackspace(): void {
    if (freshResult.current) {
      return;
    }
    let modifiedDisplay = display.slice(0, display.length - 1);
    if (modifiedDisplay === "-" || modifiedDisplay.length === 0) {
      modifiedDisplay = "0";
    }
    setDisplay(modifiedDisplay);
  }

  function onToggleSign(): void {
    if (display === "0") return;
    if (display.startsWith("-")) {
      setDisplay(display.slice(1));
    } else {
      setDisplay("-" + display);
    }
  }

  return {
    display,
    expression,
    error,
    hasPendingOp,
    onDigit,
    onOperator,
    onUnary,
    onEqual,
    onClear,
    onBackspace,
    onToggleSign,
  };
}
