import React from "react";
import ReactDOM from "react-dom/client";
import { App } from "./App";
import "./index.css";

// ---------------------------------------------------------------------------
// Entry point — mounts the React tree into the #root element in index.html.
// Nothing else belongs here.
// ---------------------------------------------------------------------------
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
