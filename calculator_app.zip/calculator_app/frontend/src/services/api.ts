import type { CalcError, CalculateResponse, Operation } from "../types";

// In dev, Vite proxies /api to the backend. In production, Nginx does the same.
const BASE_URL = "/api/v1/calculator";

// The only function that talks to the backend.
// Throws CalcError on domain errors (4xx), plain Error on network failure.
export async function calculate(
  operation: Operation,
  operands: number[],
): Promise<CalculateResponse> {
  const response = await fetch(BASE_URL + "/calculate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ operation, operands }),
  });

  if (!response.ok) {
    const error: CalcError = await response.json();
    throw error;
  }

  return response.json() as Promise<CalculateResponse>;
}
