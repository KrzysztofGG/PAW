// ---------------------------------------------------------------------------
// Vitest setup file — runs before every test file.
//
// Add global test utilities here:
//   - @testing-library/jest-dom matchers (toBeInTheDocument, toHaveClass, …)
//   - global fetch mock baseline
//   - any other test-wide configuration
// ---------------------------------------------------------------------------

import { vi } from "vitest";

globalThis.fetch = vi.fn();
