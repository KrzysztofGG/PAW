import { renderHook, act } from "@testing-library/react";
import { vi, describe, it, expect, beforeEach } from "vitest";
import { useCalculator } from "../hooks/useCalculator";
import { Operation } from "../types";

function mockSuccess(result: number, expression: string) {
    vi.mocked(fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ result, expression, operation: "add" }),
    } as Response);
}

function mockError(error_code: string, detail: string) {
    vi.mocked(fetch).mockResolvedValueOnce({
        ok: false,
        json: async () => ({ error_code, detail }),
    } as Response )
}

beforeEach(() => vi.clearAllMocks());

describe("onDigit", () => {
    it("appends digit to display", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("5"));
        expect(result.current.display).toBe("5");

        act(() => result.current.onDigit("3"));
        expect(result.current.display).toBe("53");
    });
    
    it("replaces 0 with digit", () => {
        const { result } = renderHook(() => useCalculator());
        
        act(() => result.current.onDigit("7"));
        expect(result.current.display).toBe("7");
    });

    it("prepends 0 to leading decimal point", () => {
        const { result } = renderHook(() => useCalculator());
        
        act(() => result.current.onDigit("."));
        expect(result.current.display).toBe("0.");
    });

    it("makes decimal character isn't used twice", () => {
        const { result } = renderHook(() => useCalculator());
        
        act(() => result.current.onDigit("."));
        expect(result.current.display).toBe("0.");
        
        act(() => result.current.onDigit("."));
        expect(result.current.display).toBe("0.");
    });

    it("silently blocks digits beyond 15 characters", () => {
        const { result } = renderHook(() => useCalculator());

        for (let i = 0; i < 20; i++) {
            act(() => result.current.onDigit("1"));
        }

        expect(result.current.display.length).toBe(15);
        expect(result.current.error).toBeNull();
    });

    it("clears error on next digit", async () => {
        mockError("DIVISION_BY_ZERO", "Division by zero is not allowed");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.DIVIDE));
        act(() => result.current.onDigit("0"));
        await act(() => result.current.onEqual());

        expect(result.current.error).toBe("Division by zero is not allowed");

        act(() => result.current.onDigit("3"));
        expect(result.current.error).toBeNull();
    });
});

describe("onEqual", () => {
    it("calls API and updates display with result", async () => {
        mockSuccess(8, "3 + 5 = 8");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.ADD));
        act(() => result.current.onDigit("5"));
    
        await act(() => result.current.onEqual());

        expect(result.current.display).toBe("8");
        expect(result.current.expression).toBe("3 + 5 = 8");
        expect(result.current.error).toBeNull();
    });

    it("on API error: clears state and shows error message", async () => {
        mockError("DIVISION_BY_ZERO", "Division by zero is not allowed");
        const { result } = renderHook(() => useCalculator());
    
        act(() => result.current.onDigit("5"));
        await act(() => result.current.onOperator(Operation.DIVIDE));
        act(() => result.current.onDigit("0"));
    
        await act(() => result.current.onEqual());
    
        expect(result.current.display).toBe("0");
        expect(result.current.error).toBe("Division by zero is not allowed");
        expect(result.current.hasPendingOp).toBe(false);
    });

    it("is no-op when no operator is pending", async () => {
        const { result } = renderHook(() => useCalculator());
        act(() => result.current.onDigit("5"));
        await act(() => result.current.onEqual());
        expect(result.current.display).toBe("5"); // unchanged
    });

    it("next digit after operator starts fresh", async () => {
        const { result } = renderHook(() => useCalculator());
        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.ADD));
        act(() => result.current.onDigit("5"));
        expect(result.current.display).toBe("5"); // not "35"
    });
});

describe("onClear", () => {
    it("resets display, expression and error", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("9"));
        act(() => result.current.onClear());

        expect(result.current.display).toBe("0");
        expect(result.current.expression).toBe("");
        expect(result.current.error).toBeNull();
        expect(result.current.hasPendingOp).toBe(false);
    });

    it("clears error message", async () => {
        mockError("DIVISION_BY_ZERO", "Division by zero is not allowed");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("5"));
        await act(() => result.current.onOperator(Operation.DIVIDE));
        act(() => result.current.onDigit("0"));
        await act(() => result.current.onEqual());
        act(() => result.current.onClear());

        expect(result.current.error).toBeNull();
        expect(result.current.display).toBe("0");
    });
});

describe("onBackspace", () => {
    it("removes last character", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("1"));
        act(() => result.current.onDigit("2"));
        act(() => result.current.onDigit("3"));
        act(() => result.current.onBackspace());

        expect(result.current.display).toBe("12");
    });

    it("resets to 0 when last digit is deleted", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("5"));
        act(() => result.current.onBackspace());

        expect(result.current.display).toBe("0");
    });

    it("is no-op after fresh result", async () => {
        mockSuccess(8, "3 + 5 = 8");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.ADD));
        act(() => result.current.onDigit("5"));
        await act(() => result.current.onEqual());
        act(() => result.current.onBackspace());

        expect(result.current.display).toBe("8");
    });
});

describe("onToggleSign", () => {
    it("negates a positive number", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("5"));
        act(() => result.current.onToggleSign());

        expect(result.current.display).toBe("-5");
    });

    it("removes minus from a negative number", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("5"));
        act(() => result.current.onToggleSign());
        act(() => result.current.onToggleSign());

        expect(result.current.display).toBe("5");
    });

    it("is no-op on zero", () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onToggleSign());

        expect(result.current.display).toBe("0");
    });
});

describe("onOperator", () => {
    it("stores pending operator", async () => {
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.ADD));

        expect(result.current.hasPendingOp).toBe(true);
    });

    it("chains operations by evaluating pending before storing new", async () => {
        mockSuccess(8, "3 + 5 = 8");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("3"));
        await act(() => result.current.onOperator(Operation.ADD));
        act(() => result.current.onDigit("5"));
        await act(() => result.current.onOperator(Operation.MULTIPLY));

        expect(result.current.display).toBe("8");
        expect(result.current.hasPendingOp).toBe(true);
    });
});

describe("onUnary", () => {
    it("calls API and updates display", async () => {
        mockSuccess(3, "√9 = 3");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("9"));
        await act(() => result.current.onUnary(Operation.SQRT));

        expect(result.current.display).toBe("3");
        expect(result.current.expression).toBe("√9 = 3");
    });

    it("on error: clears state and shows error", async () => {
        mockError("SQRT_OF_NEGATIVE", "Cannot take square root of a negative number");
        const { result } = renderHook(() => useCalculator());

        act(() => result.current.onDigit("6"));
        act(() => result.current.onToggleSign());
        await act(() => result.current.onUnary(Operation.SQRT));

        expect(result.current.display).toBe("0");
        expect(result.current.error).toBe("Cannot take square root of a negative number");
    });
});