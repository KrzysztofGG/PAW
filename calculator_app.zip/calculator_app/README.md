# Calculator App

A full-stack calculator with a React frontend and FastAPI backend.

## Running the App

### With Docker
```bash
docker compose up --build
```
- Frontend: http://localhost:5173
- Backend: http://localhost:8000

### Without Docker

**Backend:**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## Running Tests

**Backend:**
```bash
cd backend && source venv/bin/activate
python -m pytest tests/ -v
```

**Frontend:**
```bash
cd frontend
npm test
```

## API Reference

**Endpoint:** `POST /api/v1/calculator/calculate`

**Request:**
```json
{ "operation": "add", "operands": [3, 5] }
```

Supported operations: `add`, `subtract`, `multiply`, `divide`, `power`, `sqrt`, `percent`

**Success response** (`200`):
```json
{ "result": 8, "expression": "3.0 + 5.0 = 8.0", "operation": "add" }
```

**Error response** (`422`):
```json
{ "error_code": "DIVISION_BY_ZERO", "detail": "Division by zero is not allowed" }
```

Error codes: `DIVISION_BY_ZERO`, `SQRT_OF_NEGATIVE`, `INVALID_OPERAND_COUNT`, `INVALID_RESULT`, `UNKNOWN_OPERATION`

---

## Design Decisions

### Frontend

The UI is divided into two components:
- **Display** — shows the current value, completed expression, and any errors
- **ButtonPad** — contains all numerical and operational input buttons

Core logic is defined in `useCalculator.ts`, which holds calculator state and defines actions used by buttons:

| Action | Description |
|---|---|
| `onDigit` | Adds a digit to the display, enforcing a 15-character limit and preventing duplicate `.` |
| `onOperator` | If no operator is pending, stores the current display value and operator. If one is already pending, evaluates the previous operation first (chaining) |
| `onUnary` | Calls the API to calculate unary operations (square root, percentage) |
| `onEqual` | Calls the API using the pending operator and operands, then clears pending state |
| `onClear` | Resets all calculator state |
| `onBackspace` | Removes the last character from the display |
| `onToggleSign` | Toggles the sign of the current display value |

#### Button–Action Coupling

Buttons are wired to actions through a three-layer chain:

1. **`useCalculator`** (hook) — defines all actions and owns the calculator state. Returns them alongside display values.

2. **`Calculator`** (component) — calls `useCalculator()` and passes both state and actions down as props to `ButtonPad`.

3. **`ButtonPad`** (component) — defines a `BUTTON_CONFIG` array where each entry declares a button's label, visual variant, and an `action` callback that calls the appropriate hook function. The array is mapped to `CalcButton` components at render time.

Each `CalcButton` receives a single `onClick` prop — it has no knowledge of what the action does, it just calls it. This keeps the button purely presentational.

```
useCalculator()
  └── Calculator
        ├── Display          ← receives display, expression, error
        └── ButtonPad        ← receives all actions + display state
              └── BUTTON_CONFIG[]
                    └── <CalcButton onClick={action} />
```

The `=` button and `.` button have conditional `disabled` props — `=` is disabled when no operator is pending (`hasPendingOp`), and `.` is disabled when the display already contains a decimal point.

#### Keyboard Shortcuts

| Key(s) | Action |
|---|---|
| `0`–`9`, `.` | Digit input |
| `+`, `-`, `*`, `/`, `^` | Operators (add, subtract, multiply, divide, power) |
| `r` | Square root |
| `%` | Percent |
| `Enter`, `=` | Equals |
| `Escape` | Clear |
| `Backspace` | Backspace |

### Backend

The backend is a FastAPI microservice exposing a single `/calculate` endpoint at `/api/v1/calculator/`.

Requests contain an `operation` field and an `operands` list (one or two values depending on the operation). Calculation logic lives in `calculator.py`, which handles invalid inputs (division by zero, square root of a negative number, overflow) by raising typed `CalculationError` exceptions with a specific `error_code`.

The response includes the numeric result, a formatted expression string, and the original operation on success, or an `error_code` and `detail` message on failure.
